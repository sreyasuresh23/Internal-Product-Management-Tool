const API_URL = "http://localhost:8080/api/categories";

document.getElementById("categoryForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const name = document.getElementById("categoryName").value;

  await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name })
  });

  loadCategories();
});

async function loadCategories() {
  const res = await fetch(API_URL);
  const categories = await res.json();

  const list = document.getElementById("categoryList");
  list.innerHTML = "";

  categories.forEach(cat => {
    const li = document.createElement("li");
    li.className = "list-group-item d-flex justify-content-between align-items-center";
    li.innerHTML = `${cat.name} 
      <button class="btn btn-danger btn-sm" onclick="deleteCategory(${cat.id})">Delete</button>`;
    list.appendChild(li);
  });
}

async function deleteCategory(id) {
  await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  loadCategories();
}

loadCategories();
