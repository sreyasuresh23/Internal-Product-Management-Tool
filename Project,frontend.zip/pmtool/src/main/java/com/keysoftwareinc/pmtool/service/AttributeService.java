package com.keysoftwareinc.pmtool.service;


import com.keysoftwareinc.pmtool.model.Attribute;
import com.keysoftwareinc.pmtool.repository.AttributeRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AttributeService {

    private final AttributeRepository attributeRepository;

    public AttributeService(AttributeRepository attributeRepository) {
        this.attributeRepository = attributeRepository;
    }

    public List<Attribute> getAllAttributes() {
        return attributeRepository.findAll();
    }

    public Optional<Attribute> getAttributeById(Long id) {
        return attributeRepository.findById(id);
    }

    public Attribute saveAttribute(Attribute attribute) {
        return attributeRepository.save(attribute);
    }

    public void deleteAttribute(Long id) {
        attributeRepository.deleteById(id);
    }
}
