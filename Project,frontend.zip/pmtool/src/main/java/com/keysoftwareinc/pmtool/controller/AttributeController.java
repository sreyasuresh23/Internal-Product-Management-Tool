package com.keysoftwareinc.pmtool.controller;

import com.keysoftwareinc.pmtool.model.Attribute;
import com.keysoftwareinc.pmtool.service.AttributeService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/attributes")
public class AttributeController {

    private final AttributeService attributeService;

    public AttributeController(AttributeService attributeService) {
        this.attributeService = attributeService;
    }

    @GetMapping
    public List<Attribute> getAllAttributes() {
        return attributeService.getAllAttributes();
    }

    @GetMapping("/{id}")
    public Attribute getAttributeById(@PathVariable Long id) {
        return attributeService.getAttributeById(id).orElse(null);
    }

    @PostMapping
    public Attribute createAttribute(@RequestBody Attribute attribute) {
        return attributeService.saveAttribute(attribute);
    }

    @DeleteMapping("/{id}")
    public void deleteAttribute(@PathVariable Long id) {
        attributeService.deleteAttribute(id);
    }
}
